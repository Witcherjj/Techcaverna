// src/config.js
const API_BASE_URL = "https://techcaverna.shop";

export default API_BASE_URL;

